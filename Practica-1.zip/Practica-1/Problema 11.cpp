/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int numero;
    cout << "Por favor ingrese un número entero: ";
    cin >> numero;

    int minimo_comun_multiplo = 1;

    for (int i = 2; i <= numero; i=i+1) {
        int a = minimo_comun_multiplo;
        int b = i;
        while (b != 0) {
            int variable_temporal = b;
            b = a % b;
            a = variable_temporal;
        }

        minimo_comun_multiplo = (minimo_comun_multiplo * i) / a;
    }

    cout << "El MCM es: " << minimo_comun_multiplo << endl;

    return 0;
}