/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int numero;
    cout << "Ingrese un número entero para comenzar: ";
    cin >> numero;

    int suma = 0;

    // Iterar sobre todos los números desde 2 hasta el número ingresado
    for (int i=2; i < numero; i=i+1) {
        bool Primo = true;

        // Verificar si el número actual es primo
        for (int j=2; j * j <= i; j=j+1) {
            if (i % j == 0) {
                Primo = false;
                break;
            }
        }

        // Si el número actual es primo, agregarlo a la suma
        if (Primo) {
            suma= suma + i;
        }
    }

    cout << "El resultado de la suma es: " << suma << endl;

    return 0;
}
