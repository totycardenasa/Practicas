/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    char caracter; 
    cout << "'Este programa identifica vocales y consonantes'" << endl;
    cout << "Ingrese el caracter:";
    cin >> caracter; 
    if ((caracter >= 65 && caracter <= 90) || (caracter >= 97 && caracter <= 122)) {
        if (caracter == 'A' || caracter == 'E' || caracter == 'I' || caracter == 'O' || caracter == 'U' ||
            caracter == 'a' || caracter == 'e' || caracter == 'i' || caracter == 'o' || caracter == 'u') {
            cout << "El caracter " << caracter << " es una vocal." << endl;}
        else {
        cout << "El caracter " << caracter << " no es una vocal, es una consonante." << endl;}
    } else {
        cout << "El caracter " << caracter << " no es una letra." << endl;
    }
    return 0;
}