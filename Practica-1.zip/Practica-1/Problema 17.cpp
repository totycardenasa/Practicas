/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;



int main()
{
    int i, j=0, k=0, N, num;
    cout << "Ingrese un numero: ";
    cin >> num;
    for(i=1;k<=num;i++){
        N = (i*(i+1))/2;
        k=0;
        for(j=1;j<=N;j++){
            if(N%j==0){
                k+=1;
            }
                }
        }
    cout <<  "El numero es: "<< N << " que tiene " << k << " divisores.";
        return 0;
}