/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

    

#include <iostream>
using namespace std;

int main() {
    int numero_mayor = 100; 
    int numero_menor = 0;  
    char simbolo;
    int numero_adivinado;
    
    cout << "Piense en un número entre " << numero_menor << " y " << numero_mayor << "." << endl;
    while (true) {
        numero_adivinado = (numero_mayor + numero_menor) / 2;

        cout << "¿Es " << numero_adivinado << " tu número?" << endl;
        cout << endl <<" Ingresa '=','>','<' segun sea el caso: "<<endl;
        cin >> simbolo;

        if (simbolo == '>') {
            numero_menor = numero_adivinado + 1;
        } else if (simbolo == '<') {
            numero_mayor = numero_adivinado - 1;
        } else if (simbolo == '=') {
            cout << "¡Adiviné! Tu número es " << numero_adivinado << "." << endl;
            break; 
        } 
    }
    
    return 0;
}