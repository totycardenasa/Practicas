/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int numero;
    cout << "'Este programa muestra patrones formados por '*' en la pantalla.' " << endl;
    cout << "Por favor ingrese un número entero impar:" << endl;
    cin >> numero;
    
    while (numero % 2 == 0) {
        cout << "Error, ingrese un número impar." << endl;
        cin >> numero;
    }

    // Imprimir la parte superior del patrón
    for (int i = 1; i <= numero; i=i+2) {
        for (int j = 1; j <= i; j= j+1) {
            cout << "*";
        }
        cout << endl;
    }

    // Imprimir la parte inferior del patrón
    for (int i=numero-2; i >= 1; i =i-2) {
        for (int j = 1; j <= i; j=j+1) {
            cout << "*";
        }
        cout << endl;
    }

    return 0;
}
    
    