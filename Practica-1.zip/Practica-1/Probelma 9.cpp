/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Ingrese un número entero:";
    cin >> N; 
    int suma = 0;
    int variable_temporal=N; 
    
    while (variable_temporal != 0) {
        int digito = variable_temporal % 10; 
        int potencia = digito; 
        
        for (int i = 1; i < digito; i=i+1) { 
            potencia = potencia * digito;
        }

        suma = suma + potencia; 
        variable_temporal=variable_temporal/ 10; 
    
    }

    cout << "El resultado de la suma es: " << suma << endl;

    return 0;
}

 