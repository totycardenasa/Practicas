/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
using namespace std;

int main() {
    cout << "Este programa realiza operaciones de suma, resta, multiplicacion y division entre dos numeros:" << endl;
    int numero_uno,numero_dos;
    int operador;
    cout << "Ingrese el primer número:";
    cin >> numero_uno;
    cout << "Ingrese el segundo número:";
    cin >> numero_dos;
    cout << "Escoja un numero de acuerdo a la operacion que desea calcular" << endl;
    cout << "1) suma" << endl << "2) resta" << endl << "3) multiplicacion" << endl << "4) division" << endl;
    cout << "Ingrese el numero de la operacion:";
    cin >> operador;
    int suma,resta,multiplicacion,division;
    if (operador == 1){
    suma = numero_uno + numero_dos;
    cout << endl << "La suma entre " << numero_uno << " y " << numero_dos << " es: " << suma;
    }
    else if (operador == 2){
    resta = numero_uno - numero_dos;
    cout << "La resta entre " << numero_uno << " y " << numero_dos << " es: " << resta;}
    else if (operador == 3){
    multiplicacion = numero_uno * numero_dos;
    cout << "La multiplicacion entre " << numero_uno << " y " << numero_dos << " es: " << multiplicacion;
    }
    else if (operador ==4 ){
    division = numero_uno/numero_dos;
    cout << "La division entre " << numero_uno << " y " << numero_dos << " es: " << division;
    }
    return 0;
}
   