/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main(){
int day,month,year;
cout << "'Este programa es capaz de calcular si una fecha es válida o no'"<<endl;
cout << "Ingrese el día: " << endl;
cin >> day;
cout << "Ingrese el mes: " << endl;
cin >> month;
cout << "Ingrese el año: " << endl;
cin >> year;

if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {//el año es bisiesto
  cout << "El formato " << day << "/" << month << "/" << year << " es una fecha válida en bisiesto.";}
   else if( day > 31 ||  month > 12) { 
       cout << "El formato " << day << "/"<< month << " es una fecha inválida.";}
else{ 
    cout << "El formato " << day << "/" << month << "/" << year << " es una fecha válida.";}
return 0;
}