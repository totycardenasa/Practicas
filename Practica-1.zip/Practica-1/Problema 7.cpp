/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int number;
    cout << "Este programa funciona como la serie de 'Fibonacci'"<<endl;
    cout << "Ingrese un número entero cualquiera para comenzar:"<< endl;
    cin >> number;

    int a=1; 
    int b=1;  // Doy inicio a los dos primeros términos de la serie de Fibonacci
    int suma=0;

    // Generamos la serie de Fibonacci y calculamos la suma de los números pares menores que n
    while (b < number) {
        if (b % 2 == 0) {
            suma=suma+b; // Sumamos el número par a la suma
        }
        int variable_temporal=b;
        b = a + b;
        a = variable_temporal;
    }

    cout << "El resultado de la suma:" << suma << endl;

    return 0;
}
    
        