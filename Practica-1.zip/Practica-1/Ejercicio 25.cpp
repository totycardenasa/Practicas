/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Ingresa un número: ";
    cin >> n;

    // Contador para almacenar la cantidad de dígitos
    int contador = 0;

    // Manejo especial para el caso de n = 0
    if (n == 0) {
        contador = 1;
    } else {
        // Iteramos mientras n no sea igual a 0
        while (n != 0) {
            // Dividimos n por 10 para eliminar el dígito menos significativo
            n = n / 10;
            // Incrementamos el contador de dígitos
            contador = contador + 1;
        }
    }

    cout << " La cantidad de dígitos en el numero ingresado es: "  << contador;

    return 0;
}
