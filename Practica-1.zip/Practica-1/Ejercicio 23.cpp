/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int numero_uno, numero_dos,mayor;
    cout << "Este programa calcula el MCM entre dos números." << endl;
    cout << "Ingrese el primer número: ";
    cin >> numero_uno;
    cout << "Ingrese el segundo número: ";
    cin >> numero_dos;

    if (numero_uno > numero_dos){
        mayor = numero_uno
    }
    else {
        mayor = numero_dos
    }
    
    int mcm = mayor;

    while (true) {
        if (mcm % numero_uno == 0 && mcm % numero_dos == 0) {
            break;
        }
        mcm = mcm + mayor;
    }

    cout << "El MCM es: " << mcm << endl;

    return 0;
}
