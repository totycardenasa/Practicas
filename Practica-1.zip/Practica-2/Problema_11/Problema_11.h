#ifndef PROBLEMA_11_H
#define PROBLEMA_11_H

#include <iostream>
using namespace std;

void imprimirMatriz(const char arreglo_bidimensional[][20], int filas, int columnas);

#endif // PROBLEMA_11_H
