#include <Problema_11.h>

void imprimirMatriz(const char arreglo_bidimensional[15][20], int filas, int columnas) {
    //Este codigo imprime la mtriz
    for (int i = 0; i < filas; i=i+1) {
        cout << char('A' + i) << " ";
        for (int j = 0; j < columnas; j=j+1) {
            cout << arreglo_bidimensional[i][j] << " ";
        }
        cout << endl;
    }
}
