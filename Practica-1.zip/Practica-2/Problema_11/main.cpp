
#include <Problema_11.h>

int main() {
    const int FILAS = 15;
    const int COLUMNAS = 20;
    char arreglo_bidimensional[FILAS][COLUMNAS];


    for (int i = 0; i < FILAS; i=i+1) {
        for (int j = 0; j < COLUMNAS; j=j+1) {
            arreglo_bidimensional[i][j] = '-';
        }
    }

    cout << "Este programa permite manejar las reservas y cancelaciones de asientos en una sala de cine" << endl;
    cout << "Asientos disponibles:" << endl;
    imprimirMatriz(arreglo_bidimensional, FILAS, COLUMNAS);
    cout << "Asientos disponibles: '-'" << endl;
    cout << "Asientos reservados: '+'" << endl;

    while (true) {
        int choice;
        cout << "OPCION 1: 'Reservar asientos'" << endl;
        cout << "OPCION 2: 'Cancelar asientos'" << endl;
        cout << "OPCION 3: 'Salir'" << endl;
        cout << "Ingrese el numero de la opcion deseada: ";
        cin >> choice;

        if (choice == 1) {
            char fila;
            int columna;
            cout << "Ingrese la letra (A-O) de la fila en la que desea estar: ";
            cin >> fila;
            cout << "Ingrese el numero (1-20) del asiento: ";
            cin >> columna;

            // Verificar si el asiento esta disponible y reservarlo si es así
            if (fila >= 'A' && fila <= 'O' && columna >= 1 && columna <= 20) {
                if (arreglo_bidimensional[fila - 'A'][columna - 1] == '-') {
                    arreglo_bidimensional[fila - 'A'][columna - 1] = '+';
                    cout << "Asiento reservado con exito." << endl;
                } else {
                    cout << "El asiento ya esta reservado, elija otro." << endl;
                }
            } else {
                cout << "ERROR!! Por favor, ingrese una fila entre A-O y una columna entre 1-20." << endl;
            }
        }

        else if (choice == 2) {
            char fila;
            int columna;
            cout << "Ingrese la letra (A-O) de la fila del asiento a cancelar: ";
            cin >> fila;
            cout << "Ingrese el numero (1-20) del asiento a cancelar: ";
            cin >> columna;

            // Verificar si el asiento está reservado y cancelarlo si es así
            if (fila >= 'A' && fila <= 'O' && columna >= 1 && columna <= 20) {
                if (arreglo_bidimensional[fila - 'A'][columna - 1] == '+') {
                    arreglo_bidimensional[fila - 'A'][columna - 1] = '-';
                    cout << "Reserva cancelada con exito." << endl;
                } else {
                    cout << "El asiento no esta reservado actualmente." << endl;
                }
            } else {
                cout << "ERROR!! Por favor, ingrese una fila entre A-O y una columna entre 1-20." << endl;
            }
        }

        else if (choice == 3) {
            cout << "Saliendo del programa." << endl;
            break;
        } else {
            cout << "Opcion no valida. Por favor, ingrese 1, 2 o 3." << endl;
        }

        // Imprimir la información actualizada de los asientos después de cada acción
        cout << "Informacion actualizada de los asientos:" << endl;
        imprimirMatriz(arreglo_bidimensional, FILAS, COLUMNAS);
        cout << "Asientos disponibles: '-'" << endl;
        cout << "Asientos reservados: '+'" << endl;
    }

    return 0;
}
