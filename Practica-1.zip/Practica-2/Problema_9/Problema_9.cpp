int funcion_2(const char* cadena) {
    int contador = 0;
    while (*cadena != '\0') {
        contador=contador+1;
        cadena=cadena+1;
    }
    return contador;
}

int* funcion_1(char* cadena, int N) {
    int longitud_cadena = funcion_2(cadena);
    int cantidad_numeros = (longitud_cadena + N - 1) / N; // Calculamos la cantidad de números de N cifras
    int* arreglo = new int[cantidad_numeros];

    int indice_arreglo = 0;
    int numero_actual = 0;
    int potencia_10 = 1;

    for (int i = longitud_cadena - 1; i >= 0; i=i-1) {
        numero_actual = numero_actual + (cadena[i] - '0') * potencia_10;
        potencia_10 = potencia_10 * 10;


        if ((longitud_cadena - i) % N == 0 || i == 0) {
            arreglo[indice_arreglo] = numero_actual;
            indice_arreglo = indice_arreglo + 1;
            numero_actual = 0;
            potencia_10 = 1;
        }
    }

    // Agregar ceros a la izquierda si es necesario
    for (int i = cantidad_numeros - 1; i > 0; i=i-1) {
        if (arreglo[i] < 1) {
            arreglo[i] = arreglo[i] * 10;// Se agrega un cero a la izquierda
        }
    }




    return arreglo;
}





