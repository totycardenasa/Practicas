#include <Problema_9.h>

int main() {
    int N;
    char cadena[100];
    cout << "Ingrese un numero entero: ";
    cin >> N;
    cout << "Ingrese una cadena de caracteres numericos: ";
    cin >> cadena;
    cout << cadena << endl;

    int longitud_cadena = funcion_2(cadena); // se almacena la longitud del arreglo y se invoca la funcion
    int* numeros = funcion_1(cadena, N);//se invoca a la funcion 1
    int cantidad_numeros = (longitud_cadena + N - 1) / N;

    // Sumar solo los números de N cifras en el arreglo
    int suma = 0;
    for(int i = 0; i < cantidad_numeros; i=i+1) {
        suma = suma + numeros[i];
    }

    cout << "Original: " << cadena << endl;
    cout << "Suma: " << suma << endl;
    delete[] numeros;
    return 0;

}
