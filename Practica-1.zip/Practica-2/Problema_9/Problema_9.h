#ifndef PROBLEMA_9_H
#define PROBLEMA_9_H

#include <iostream>
using namespace std;

int* funcion_1(char* cadena, int N);
int funcion_2(const char* cadena);

#endif // PROBLEMA_9_H


