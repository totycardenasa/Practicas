#include <iostream>
using namespace std;
#include <string>


std::string mi_funcion(int numero); //declaracion de la funcion

int main() {
    int numero;
    cout << "Ingrese un numero entero: ";
    cin >> numero;

    std::string resultado = mi_funcion(numero); // Llamada a la función

    cout << "La cadena de caracteres resultante es: " <<"'"<< resultado << "'" << std::endl;

    return 0;
}

std::string mi_funcion(int numero) {
    std::string cadena;
    bool negativo = false;

    if (numero == 0) {
        cadena = "0";
    }

    else {

        if (numero < 0) {
            negativo = true;
            numero = -numero;
        }


        while (numero > 0) {
            char digito = '0' + (numero % 10);
            cadena = digito + cadena;
            numero = numero/10;
        }


        if (negativo==true) {
            cadena = "-" + cadena;
        }
    }


    return cadena;
}
