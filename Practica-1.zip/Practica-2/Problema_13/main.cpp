#include <Problema_13.h>

int main() {
    // Definimos la matriz de la imagen
    int matriz[6][8] = {
        {0, 3, 4, 0, 0, 0, 6, 8},
        {5, 13, 6, 0, 0, 0, 2, 3},
        {2, 6, 2, 7, 3, 0, 10, 0},
        {0, 0, 4, 15, 4, 1, 6, 0},
        {0, 0, 7, 12, 6, 9, 10, 4},
        {5, 0, 6, 10, 6, 4, 8, 0}
    };

    // Calculamos el número de filas y columnas de la matriz
    int filas = 6;
    int columnas = 8;

    // Llamamos a la función para contar estrellas
    int numeroEstrellas = contarEstrellas((int*)matriz, filas, columnas);

    cout << "El número de estrellas encontradas en la imagen es: " << numeroEstrellas << endl;

    return 0;
}
