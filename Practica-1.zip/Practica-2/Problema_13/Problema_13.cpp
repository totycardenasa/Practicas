int contarEstrellas(int *matriz, int filas, int columnas) {
    int contadorEstrellas = 0;

    // Recorremos la matriz omitiendo los bordes,dos bucles for anidados para recorrer cada elemento de la matriz, comenzando desde el segundo elemento hasta el penúltimo elemento en ambas dimensiones
    for (int i = 1; i < filas - 1; i=i+1) {
        for (int j = 1; j < columnas - 1; j=j+1) {
            // Calculamos la suma de los elementos adyacentes
            int sumaAdyacentes = matriz[i * columnas + j] + matriz[i * columnas + j - 1] + matriz[i * columnas + j + 1] + matriz[(i - 1) * columnas + j] + matriz[(i + 1) * columnas + j];
            // Verificamos si se cumple la condición para ser una estrella
            if (sumaAdyacentes > 6 * 5) { // Comparamos con 6 multiplicado por 5
                contadorEstrellas = contadorEstrellas + 1;
            }
        }
    }

    return contadorEstrellas;
}
