#ifndef PROBLEMA_13_H
#define PROBLEMA_13_H

#include <iostream>
using namespace std;

int contarEstrellas(int *matriz, int filas, int columnas);



#endif // PROBLEMA_13_H
