#include <iostream>
using namespace std;

int main()
{
    int cantidad, resto,faltante=0, billetes_50=0,billetes_20=0,billetes_10=0,billetes_5=0,billetes_2=0,billetes_1=0,monedas_500=0,monedas_200=0,monedas_100=0,monedas_50=0;
    int arreglo[10] = {50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50};
    cout << "Este programa muestra en pantalla la mínima combinación de billetes y monedas para una cantidad de dinero determinada" << endl;
    cout << "Ingrese un valor: ";
    cin >> cantidad;

    while (cantidad > 0) {
        if (cantidad >= arreglo[0]) {
            billetes_50 = cantidad / arreglo[0];
            resto = cantidad % arreglo[0];

        }
        else if (resto >= arreglo[1] || cantidad > arreglo[1]) {
            billetes_20 = cantidad / arreglo[1];
            resto = cantidad % arreglo[1];

        }
        else if (resto >= arreglo[2] || cantidad > arreglo[2]) {
            billetes_10 = cantidad / arreglo[2];
            resto = cantidad % arreglo[2];

        }
        else if (resto >= arreglo[3] || cantidad > arreglo[3]) {
            billetes_5 = cantidad / arreglo[3];
            resto = cantidad % arreglo[3];

        }
        else if (resto >= arreglo[4] || cantidad > arreglo[4]) {
            billetes_2 = cantidad / arreglo[4];
            resto = cantidad % arreglo[4];

        }
        else if (resto >= arreglo[5] || cantidad > arreglo[5]) {
            billetes_1 = cantidad / arreglo[5];
            resto = cantidad % arreglo[5];

        }
        else if (resto >= arreglo[6] || cantidad > arreglo[6]) {
            monedas_500 = cantidad / arreglo[6];
            resto = cantidad % arreglo[6];

        }
        else if (resto >= arreglo[7] || cantidad > arreglo[7]) {
            monedas_200 = cantidad / arreglo[7];
            resto = cantidad % arreglo[7];

        }
        else if (resto >= arreglo[8] || cantidad > arreglo[8]) {
            monedas_100 = cantidad / arreglo[8];
            resto = cantidad % arreglo[8];

        }
        else if (resto >= arreglo[9] || cantidad > arreglo[9]) {
            monedas_50 = cantidad / arreglo[9];
            resto = cantidad % arreglo[9];

        }
        else if (resto<arreglo[9]){
            faltante=cantidad;
        }

        cantidad = resto;
        resto = 0;

    }
     cout << "Billetes de 50000: " << billetes_50 << endl;
     cout << "Billetes de 20000: " << billetes_20 << endl;
     cout << "Billetes de 10000: " << billetes_10 << endl;
     cout << "Billetes de 5000: " << billetes_5 << endl;
     cout << "Billetes de 2000: " << billetes_2 << endl;
     cout << "Billetes de 1000: " << billetes_1 << endl;
     cout << "Monedas de 500: " << monedas_500 << endl;
     cout << "Monedas de 200: " << monedas_200 << endl;
     cout << "Monedas de 100: " << monedas_100 << endl;
     cout << "Monedas de 50: " << monedas_50 << endl;
     cout << "Faltante: " << faltante << endl;


 return 0;

}
