#include <iostream>

using namespace std;

int main() {
    char palabra[100];
    bool encontrado[256] = {false}; // Arreglo booleano para almacenar si un carácter ha sido encontrado

    cout << "Este programa elimina los caracteres repetidos en una palabra" << endl;
    cout << "Por favor ingrese una palabra: ";
    cin >> palabra;

    // Determinar la longitud de la palabra sin usar strlen
    int longitud = 0;
    while (palabra[longitud] != '\0') {
        longitud=longitud+1;
    }

    // Iterar sobre la palabra y marcar los caracteres que ya han sido encontrados
    for(int i = 0; i < longitud; i=i+1) {
        if (!encontrado[palabra[i]]) {
            encontrado[palabra[i]] = true;
        }
    }

    // Imprimir la palabra resultante sin caracteres repetidos
    cout << "La palabra resultante sin caracteres repetidos es: ";
    for(int i = 0; i < longitud; i=i+1) {
        if (encontrado[palabra[i]]) {
            cout << palabra[i];
            encontrado[palabra[i]] = false; // Restaurar el valor en el arreglo para futuras ocurrencias
        }
    }
    cout << endl;

    return 0;
}



