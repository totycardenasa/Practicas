#include <iostream>
using namespace std;

bool mi_funcion(char cadena_1[], char cadena_2[]);

int main() {
    char cadena_1[100], cadena_2[100];
    bool answer;

    cout << "Ingrese la primera palabra: ";
    cin >> cadena_1;
    cout << "Ingrese la segunda palabra: ";
    cin >> cadena_2;

    answer = mi_funcion(cadena_1, cadena_2);

    if (answer == true) {
        cout << "Las palabras ingresadas son iguales.";
    } else {
        cout << "Las palabras ingresadas son diferentes.";
    }

    return 0;
}

bool mi_funcion(char cadena_1[], char cadena_2[]) {
    int i = 0;
    while (cadena_1[i] != '\0' && cadena_2[i] != '\0') {
        if (cadena_1[i] != cadena_2[i]) {
            return false;
        }
        i=i+1;
    }
    return (cadena_1[i] == '\0' && cadena_2[i] == '\0');
}
